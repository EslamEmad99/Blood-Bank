package com.example.bloodbank.ui.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.example.bloodbank.R;
import com.example.bloodbank.adapters.OnBoardingPagerAdapter;
import com.example.bloodbank.data.models.OnBoardingModel;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class OnBoardingActivity extends AppCompatActivity {

    @BindView(R.id.activity_on_boarding_screen_viewpager)
    ViewPager screenPager;
    @BindView(R.id.activity_on_boarding_btn_next)
    Button btnNext;
    @BindView(R.id.activity_on_boarding_tab_indicator)
    TabLayout tabIndicator;
    @BindView(R.id.activity_on_boarding_btn_get_started)
    Button btnGetStarted;
    @BindView(R.id.activity_on_boarding_tv_skip)
    TextView tvSkip;

    //private ViewPager screenPager;
    OnBoardingPagerAdapter introViewPagerAdapter;
    //TabLayout tabIndicator;
    //Button btnNext;
    int position = 0;
    //Button btnGetStarted;
    Animation btnAnim;
    //TextView tvSkip;
    List<OnBoardingModel> mList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // make the activity on full screen

//        requestWindowFeature(Window.FEATURE_NO_TITLE);
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
//                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        // when this activity is about to be launch we need to check if its openened before or not

        if (restorePrefData()) {
            Intent mainActivity = new Intent(getApplicationContext(), LoginActivity.class);
            startActivity(mainActivity);
            finish();
        }

        setContentView(R.layout.activity_on_boarding);
        ButterKnife.bind(this);

        // hide the action bar

        //getSupportActionBar().hide();

        // init views
        //btnNext = findViewById(R.id.activity_on_boarding_btn_next);
        //btnGetStarted = findViewById(R.id.activity_on_boarding_btn_get_started);
        //tabIndicator = (TabLayout) findViewById(R.id.activity_on_boarding_tab_indicator);
        btnAnim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.button_animation);
        //tvSkip = findViewById(R.id.activity_on_boarding_tv_skip);

        // fill list screen

        mList = new ArrayList<>();
        mList.add(new OnBoardingModel("1 Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua, consectetur  consectetur adipiscing elit", R.drawable.onboarding_baclground_one));
        mList.add(new OnBoardingModel("2 Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua, consectetur  consectetur adipiscing elit", R.drawable.onboarding_background_two));
        mList.add(new OnBoardingModel("3 Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua, consectetur  consectetur adipiscing elit", R.drawable.onboarding_background_three));

        // setup viewpager
        //screenPager = findViewById(R.id.activity_on_boarding_screen_viewpager);
        introViewPagerAdapter = new OnBoardingPagerAdapter(this, mList);
        screenPager.setAdapter(introViewPagerAdapter);

        // setup tablayout with viewpager

        tabIndicator.setupWithViewPager(screenPager);

        // next button click Listner

//        btnNext.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//            }
//        });

        // tablayout add change listener

        tabIndicator.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab.getPosition() == mList.size() - 1) {
                    loadLastScreen();
                } else {
                    btnNext.setVisibility(View.VISIBLE);
                    btnGetStarted.setVisibility(View.INVISIBLE);
                    tvSkip.setVisibility(View.VISIBLE);
                    tabIndicator.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        // Get Started button click listener

//        btnGetStarted.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//            }
//        });

        // skip button click listener

//        tvSkip.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//            }
//        });


    }

    private boolean restorePrefData() {
        SharedPreferences pref = getApplicationContext().getSharedPreferences("myPrefs", MODE_PRIVATE);
        return pref.getBoolean("isIntroOpnend", false);
    }

    private void savePrefsData() {
        SharedPreferences pref = getApplicationContext().getSharedPreferences("myPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putBoolean("isIntroOpnend", true);
        editor.commit();
    }

    // show the GETSTARTED Button and hide the indicator and the next button
    private void loadLastScreen() {
        btnNext.setVisibility(View.INVISIBLE);
        btnGetStarted.setVisibility(View.VISIBLE);
        tvSkip.setVisibility(View.INVISIBLE);
        // tabIndicator.setVisibility(View.INVISIBLE);
        // TODO : ADD an animation the getstarted button
        // setup animation
        btnGetStarted.setAnimation(btnAnim);
    }

    @Override
    public void onBackPressed() {
        Intent a = new Intent(Intent.ACTION_MAIN);
        a.addCategory(Intent.CATEGORY_HOME);
        a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(a);
    }

    @OnClick(R.id.activity_on_boarding_btn_next)
    public void onActivityOnBoardingBtnNextClicked() {
        position = screenPager.getCurrentItem();
        if (position < mList.size()) {
            position++;
            screenPager.setCurrentItem(position);
        }
        if (position == mList.size() - 1) { // when we rech to the last screen
            // TODO : show the GETSTARTED Button and hide the indicator and the next button
            loadLastScreen();
        }
    }

    @OnClick(R.id.activity_on_boarding_btn_get_started)
    public void onActivityOnBoardingBtnGetStartedClicked() {
        //open main activity
        Intent mainActivity = new Intent(getApplicationContext(), LoginActivity.class);
        startActivity(mainActivity);
        // also we need to save a boolean value to storage so next time when the user run the app
        // we could know that he is already checked the intro screen activity
        // i'm going to use shared preferences to that process
        savePrefsData();
        finish();
    }

    @OnClick(R.id.activity_on_boarding_tv_skip)
    public void onActivityOnBoardingTvSkipClicked() {
        screenPager.setCurrentItem(mList.size());
    }
}