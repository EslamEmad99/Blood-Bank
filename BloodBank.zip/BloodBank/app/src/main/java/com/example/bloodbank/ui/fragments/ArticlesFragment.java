package com.example.bloodbank.ui.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bloodbank.R;
import com.example.bloodbank.adapters.PostsAdapter;
import com.example.bloodbank.data.models.ExamplePost;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class ArticlesFragment extends Fragment {
    View view;
    @BindView(R.id.articles_fragment_search_view)
    SearchView articlesFragmentSearchView;
    @BindView(R.id.articles_fragment_button_add_post)
    ImageView articlesFragmentButtonAddPost;
    private ArrayList<ExamplePost> mExampleList;
    private RecyclerView mRecyclerView;
    private PostsAdapter mAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_articles, container, false);
        ButterKnife.bind(this, view);
        mExampleList = new ArrayList<>();

        mExampleList.add(new ExamplePost(R.drawable.onboarding_baclground_one, "One"));
        mExampleList.add(new ExamplePost(R.drawable.onboarding_background_two, "Two"));
        mExampleList.add(new ExamplePost(R.drawable.onboarding_background_three, "Three"));

        mRecyclerView = view.findViewById(R.id.articles_fragment_recycler_view);
        mRecyclerView.setHasFixedSize(true);
        //mLayoutManager = new LinearLayoutManager(this);
        mAdapter = new PostsAdapter(mExampleList);

        //mRecyclerView.setLayoutManager(new GridLayoutManager(this,3));
        //mRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, true));
        //mRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        mRecyclerView.setAdapter(mAdapter);

        mAdapter.setOnItemClickListener(new PostsAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
//                int x = position+1;
//                mExampleList.get(position).setmText1("item " + x + " clickek");
//                mAdapter.notifyItemChanged(position);
                Toast.makeText(getContext(), "item : " + (position + 1) + " clicked", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFavoriteClick(int position) {
                Toast.makeText(getContext(), "item : " + (position + 1) + " added to favorites", Toast.LENGTH_SHORT).show();
            }
        });

        articlesFragmentSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                mAdapter.getFilter().filter(newText);
                return false;
            }
        });

        return view;
    }

    @OnClick(R.id.articles_fragment_button_add_post)
    public void onViewClicked() {
        Toast.makeText(getContext(), "fab", Toast.LENGTH_SHORT).show();
    }
}
