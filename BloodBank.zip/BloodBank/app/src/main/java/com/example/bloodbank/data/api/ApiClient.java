package com.example.bloodbank.data.api;

import com.example.bloodbank.data.models.bloodType.BloodTypeModel;
import com.example.bloodbank.data.models.city.CityModel;
import com.example.bloodbank.data.models.governate.GovernateModel;
import com.example.bloodbank.data.models.login.LoginModel;
import com.example.bloodbank.data.models.newPassword.NewPasswordModel;
import com.example.bloodbank.data.models.register.RegisterModel;
import com.example.bloodbank.data.models.resetpassword.ResetPasswordModel;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {
    private static final String BASE_URL = "http://ipda3-tech.com/blood-bank/api/v1/";
    private ApiInterface apiInterface;
    private static ApiClient INSTANCE;

    public ApiClient() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        apiInterface = retrofit.create(ApiInterface.class);
    }

    public static ApiClient getINSTANCE() {
        if (null == INSTANCE) {
            INSTANCE = new ApiClient();
        }
        return INSTANCE;
    }

    public Call<LoginModel> onLogin(String phone, String number) {
        return apiInterface.onLogin(phone, number);
    }

    public Call<ResetPasswordModel> onResetPassword(String phone) {
        return apiInterface.onResetPassword(phone);
    }

    public Call<NewPasswordModel> onNewPassword(String password,
                                                String passwordConfirmation,
                                                Integer pinCode,
                                                String phone) {
        return apiInterface.onNewPassword(password, passwordConfirmation, pinCode, phone);
    }

    public Call<BloodTypeModel> getBloodType() {
        return apiInterface.getBloodType();
    }

    public Call<GovernateModel> getGovernate() {
        return apiInterface.getGovernate();
    }

    public Call<CityModel> getCity(String governorateId) {
        return apiInterface.getCity(governorateId);
    }

    public Call<RegisterModel> onRegister(String name,
                                          String email,
                                          String birth_date,
                                          String city_id,
                                          String phone,
                                          String donation_last_date,
                                          String password,
                                          String password_confirmation,
                                          String blood_type_id) {
        return apiInterface.onRegister(
                name,
                email,
                birth_date,
                city_id,
                phone,
                donation_last_date,
                password,
                password_confirmation,
                blood_type_id);
    }
}
