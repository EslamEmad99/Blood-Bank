package com.example.bloodbank.data.api;

import com.example.bloodbank.data.models.bloodType.BloodTypeModel;
import com.example.bloodbank.data.models.city.CityModel;
import com.example.bloodbank.data.models.governate.GovernateModel;
import com.example.bloodbank.data.models.login.LoginModel;
import com.example.bloodbank.data.models.newPassword.NewPasswordModel;
import com.example.bloodbank.data.models.register.RegisterModel;
import com.example.bloodbank.data.models.resetpassword.ResetPasswordModel;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ApiInterface {

    @POST("login")
    @FormUrlEncoded
    Call<LoginModel> onLogin(@Field("phone") String phone,
                             @Field("password")String password);

    @POST("reset-password")
    @FormUrlEncoded
    Call<ResetPasswordModel> onResetPassword(@Field("phone") String phone);

    @POST("new-password")
    @FormUrlEncoded
    Call<NewPasswordModel> onNewPassword(@Field("password") String password,
                                         @Field("password_confirmation") String passwordConfirmation,
                                         @Field("pin_code") Integer pinCode,
                                         @Field("phone") String phone);

    @GET("blood-types")
    Call<BloodTypeModel> getBloodType();

    @GET("governorates")
    Call<GovernateModel> getGovernate();

    @GET("cities")
    Call<CityModel> getCity(@Query("governorate_id") String governorateId);

    @POST("signup")
    @FormUrlEncoded
    Call<RegisterModel> onRegister(@Field("name") String name,
                                      @Field("email") String email,
                                      @Field("birth_date") String birth_date,
                                      @Field("city_id") String city_id,
                                      @Field("phone") String phone,
                                      @Field("donation_last_date") String donation_last_date,
                                      @Field("password") String password,
                                      @Field("password_confirmation") String password_confirmation,
                                      @Field("blood_type_id") String blood_type_id);

}
