package com.example.bloodbank.data.models;

import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

public class ExamplePost {

    private int postImage;
    private String postDescription;

    public ExamplePost(int postImage, String postDescription) {
        this.postImage = postImage;
        this.postDescription = postDescription;
    }

    public int getPostImage() {
        return postImage;
    }

    public void setPostImage(int postImage) {
        this.postImage = postImage;
    }

    public String getPostDescription() {
        return postDescription;
    }

    public void setPostDescription(String postDescription) {
        this.postDescription = postDescription;
    }
}
