package com.example.bloodbank.ui.fragments;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import com.example.bloodbank.R;
import com.example.bloodbank.data.api.ApiClient;
import com.example.bloodbank.data.models.login.LoginModel;
import com.example.bloodbank.ui.activities.HomeActivity;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.Context.MODE_PRIVATE;

public class LoginFragment extends Fragment {
    View view;
    @BindView(R.id.fragment_login_phone_number_edit_text)
    EditText phoneNumberEditText;
    @BindView(R.id.fragment_login_password_edit_text)
    EditText passwordEditText;
    @BindView(R.id.fragment_login_remember_me_checkBox)
    CheckBox rememberMeCheckBox;
    private String phoneString;
    private String passwordString;
    private boolean isChecked = false;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (restoreIsRememberOrNotMethod()) {
            goToHomeActivity();
        }

        view = inflater.inflate(R.layout.fragment_login, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    private void goToHomeActivity() {
        Intent intent = new Intent(getContext(), HomeActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.fragment_login_remember_me_checkBox)
    public void onFragmentLoginRememberMeCheckBoxClicked() {
        if (rememberMeCheckBox.isChecked()) {
            isChecked = true;
            Toast.makeText(getContext(), String.valueOf(isChecked), Toast.LENGTH_SHORT).show();
        }
        if (!rememberMeCheckBox.isChecked()) {
            isChecked = false;
            Toast.makeText(getContext(), String.valueOf(isChecked), Toast.LENGTH_SHORT).show();
        }
    }

    @OnClick(R.id.fragment_login_forget_password_tv)
    public void onFragmentLoginForgetPasswordTvClicked() {
        ResetPasswordFragment resetPasswordFragment = new ResetPasswordFragment();
        FragmentActivity.getSupportFragmentManager().beginTransaction().replace(R.id.activity_login_fragment_container,
                resetPasswordFragment).addToBackStack(null).commit();
    }

    @OnClick(R.id.fragment_login_enter_btn)
    public void onFragmentLoginEnterBtnClicked() {
        phoneString = phoneNumberEditText.getText().toString();
        passwordString = passwordEditText.getText().toString();
        checkData(phoneString, passwordString);
    }

    private void checkData(String phone, String password) {
        Call<LoginModel> call = ApiClient.getINSTANCE().onLogin(phone, password);
        call.enqueue(new Callback<LoginModel>() {
            @Override
            public void onResponse(Call<LoginModel> call, Response<LoginModel> response) {
                if (response.body().getStatus() == 1) {
                    Toast.makeText(getContext(), response.body().getMsg(), Toast.LENGTH_LONG).show();

                    saveDataInSharedPreferences(
                            response.body().getLoginData().getApiToken(),
                            response.body().getLoginData().getClient().getId(),
                            response.body().getLoginData().getClient().getName(),
                            response.body().getLoginData().getClient().getEmail(),
                            response.body().getLoginData().getClient().getBirthDate(),
                            response.body().getLoginData().getClient().getPhone(),
                            response.body().getLoginData().getClient().getDonationLastDate(),
                            response.body().getLoginData().getClient().getCanDonate(),
                            response.body().getLoginData().getClient().getPinCode(),
                            response.body().getLoginData().getClient().getCity().getId(),
                            response.body().getLoginData().getClient().getCity().getName(),
                            response.body().getLoginData().getClient().getCity().getGovernorate().getId(),
                            response.body().getLoginData().getClient().getCity().getGovernorate().getName(),
                            response.body().getLoginData().getClient().getBloodType().getId(),
                            response.body().getLoginData().getClient().getBloodType().getName());

                    saveIsRememberOrNotMethod(isChecked);
                    goToHomeActivity();
                } else {
                    Toast.makeText(getContext(), response.body().getMsg(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<LoginModel> call, Throwable t) {
                Toast.makeText(getContext(), "something went wrong!", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void saveDataInSharedPreferences(String apiToken,
                                             Integer clientId,
                                             String clientName,
                                             String email,
                                             String birthDate,
                                             String phone,
                                             String donationLastDate,
                                             Boolean canDonate,
                                             String pinCode,
                                             Integer cityId,
                                             String cityName,
                                             Integer governateId,
                                             String governateName,
                                             Integer blood_typeId,
                                             String blood_typeName) {

        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("sharedPreferencesOfLoginData", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString("ApiToken", apiToken);
        editor.putInt("clientId", clientId);

        editor.apply();
    }

    @OnClick(R.id.fragment_login_not_registered_tv)
    public void onFragmentLoginNotRegisteredTvClicked() {
        RegisterFragment registerFragment = new RegisterFragment();
        getFragmentManager().beginTransaction().replace(R.id.activity_login_fragment_container,
                registerFragment).addToBackStack(null).commit();
    }

    private boolean restoreIsRememberOrNotMethod() {
        SharedPreferences pref = getContext().getSharedPreferences("rememebermeSharedPreferences", MODE_PRIVATE);
        boolean isIntroActivityOpnendBefore = pref.getBoolean("Remembered", false);
        return isIntroActivityOpnendBefore;
    }

    private void saveIsRememberOrNotMethod(boolean bool) {
        SharedPreferences pref = getContext().getSharedPreferences("rememebermeSharedPreferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putBoolean("Remembered", bool);
        editor.apply();
    }
}