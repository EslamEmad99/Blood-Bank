package com.example.bloodbank.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CompoundButton;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bloodbank.R;
import com.example.bloodbank.data.models.ExamplePost;

import java.util.ArrayList;

public class PostsAdapter extends RecyclerView.Adapter <PostsAdapter.ExampleViewHolder> implements Filterable {

    private ArrayList<ExamplePost> mExampleList;
    private ArrayList<ExamplePost> exampleListFull;
    private OnItemClickListener mListener;

    public interface OnItemClickListener {
        void onItemClick(int position);

        void onFavoriteClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    public static class ExampleViewHolder extends RecyclerView.ViewHolder {

        ImageView postBackground;
        TextView postDescription;
        ToggleButton favoriteToggleButton;

        public ExampleViewHolder(@NonNull View itemView , final OnItemClickListener listener) {
            super(itemView);

            postBackground = itemView.findViewById(R.id.post_background);
            favoriteToggleButton = itemView.findViewById(R.id.favorite_t_btn);
            postDescription = itemView.findViewById(R.id.post_description);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onItemClick(position);
                        }
                    }
                }
            });

            favoriteToggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                    if (isChecked){
                        if (listener != null) {
                            int position = getAdapterPosition();
                            if (position != RecyclerView.NO_POSITION) {
                                listener.onFavoriteClick(position);
                            }
                        }
                    }
                }
            });
        }
    }

    public PostsAdapter(ArrayList<ExamplePost> exampleList){
        mExampleList= exampleList;
        exampleListFull = new ArrayList<>(exampleList);
    }

    @Override
    public ExampleViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.example_post,parent,false);
        ExampleViewHolder evh = new ExampleViewHolder(view,mListener);
        return evh;
    }

    @Override
    public void onBindViewHolder(ExampleViewHolder holder, int position) {
        ExamplePost currentItem = mExampleList.get(position);

        holder.postDescription.setText(currentItem.getPostDescription());
        holder.postBackground.setImageResource(currentItem.getPostImage());
    }

    @Override
    public int getItemCount() {
        return mExampleList.size();
    }

    @Override
    public Filter getFilter() {
        return exampleFilter;
    }

    private Filter exampleFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            ArrayList<ExamplePost> filteredList = new ArrayList<>();

            if (constraint == null || constraint.length() == 0) {
                filteredList.addAll(exampleListFull);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();

                for (ExamplePost item : exampleListFull) {
                    if (item.getPostDescription().toLowerCase().contains(filterPattern)) {
                        filteredList.add(item);
                    }
                }
            }
            FilterResults results = new FilterResults();
            results.values = filteredList;
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            mExampleList.clear();
            mExampleList.addAll((ArrayList) results.values);
            notifyDataSetChanged();
        }
    };
}
