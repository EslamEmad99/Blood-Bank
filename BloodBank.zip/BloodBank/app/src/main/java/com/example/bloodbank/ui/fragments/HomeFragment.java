package com.example.bloodbank.ui.fragments;

import android.app.ActionBar;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.example.bloodbank.R;
import com.example.bloodbank.adapters.HomeFragmentSectionPageAdapter;
import com.example.bloodbank.ui.activities.HomeActivity;
import com.google.android.material.tabs.TabLayout;

import butterknife.BindView;
import butterknife.OnClick;

public class HomeFragment extends Fragment {
    View view;
    @BindView(R.id.title)
    TextView title;
    @BindView(R.id.tabs)
    TabLayout tabs;
    @BindView(R.id.view_pager)
    ViewPager viewPager;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        //getActivity().getActionBar().hide();
        // Hide the status bar.
//        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
//        view.setSystemUiVisibility(uiOptions);
// Remember that you should never show the action bar if the
// status bar is hidden, so hide that too if necessary.
        //((AppCompatActivity) getActivity()).getSupportActionBar().hide();
//
//        HomeActivity csActivity;
//        csActivity = (HomeActivity) getActivity();
//        csActivity.getSupportActionBar().hide();
        view = inflater.inflate(R.layout.fragment_home, container, false);

        HomeFragmentSectionPageAdapter homeFragmentSectionPageAdapter = new HomeFragmentSectionPageAdapter(getChildFragmentManager());
        ViewPager viewPager = view.findViewById(R.id.view_pager);
        viewPager.setAdapter(homeFragmentSectionPageAdapter);
        TabLayout tabs = view.findViewById(R.id.tabs);
        tabs.setupWithViewPager(viewPager);
        viewPager.setCurrentItem(1);
        return view;
    }


}
