package com.example.bloodbank.adapters;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.bloodbank.ui.fragments.ArticlesFragment;
import com.example.bloodbank.ui.fragments.DonationRequesrFragment;

public class HomeFragmentSectionPageAdapter extends FragmentPagerAdapter {

    //private final Context mContext;

    public HomeFragmentSectionPageAdapter(FragmentManager fm) {
        super(fm);
        //mContext = context;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {

        Fragment fragment = null;

        switch (position) {
            case 0:
                fragment = new DonationRequesrFragment();
                break;
            case 1:
                fragment = new ArticlesFragment();
                break;
        }

        assert fragment != null;
        return fragment;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
            case 0:
                return "طلبات التبرع";
            case 1:
                return "المقالات";
        }
        return null;
    }

    @Override
    public int getCount() {
        // Show 2 total pages.
        return 2;
    }
}
